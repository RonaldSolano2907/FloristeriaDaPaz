CREATE DATABASE  IF NOT EXISTS `proyectoambienteweb`;
USE `proyectoambienteweb`;

DROP TABLE IF EXISTS `trol`;
CREATE TABLE `trol` (
  `Consecutivo` int(11) NOT NULL AUTO_INCREMENT,
  `NombreRol` varchar(50) NOT NULL,
  PRIMARY KEY (`Consecutivo`)
) ENGINE=InnoDB;

INSERT INTO `trol` VALUES (1,'Administrador(a)'),(2,'Cliente(a)');

DROP TABLE IF EXISTS `tusuario`;
CREATE TABLE `tusuario` (
  `Consecutivo` bigint(11) NOT NULL AUTO_INCREMENT,
  `Identificacion` varchar(20) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `CorreoElectronico` varchar(80) NOT NULL,
  `Contrasena` varchar(10) NOT NULL,
  `Activo` bit(1) NOT NULL,
  `ConsecutivoRol` int(11) NOT NULL,
  PRIMARY KEY (`Consecutivo`),
  UNIQUE KEY `Identificacion_UNIQUE` (`Identificacion`),
  UNIQUE KEY `CorreoElectronico_UNIQUE` (`CorreoElectronico`),
  KEY `FK_ROL` (`ConsecutivoRol`),
  CONSTRAINT `FK_ROL` FOREIGN KEY (`ConsecutivoRol`) REFERENCES `trol` (`Consecutivo`)
) ENGINE=InnoDB AUTO_INCREMENT=30;

INSERT INTO `tusuario` VALUES (20,'901230815','Darrel','darrel.cr16@gmail.com','12345',_binary '',1);

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarContrasenna`(pConsecutivo bigint,
																	pCodigo varchar(10))
BEGIN

	UPDATE 	proyectoambienteweb.tusuario
    SET 	Contrasena = pCodigo
    WHERE	Consecutivo = pConsecutivo;

END ;;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarPerfil`(pConsecutivo bigint,
															   pIdentificacion varchar(20),
															   pNombre varchar(255),
															   pCorreo varchar(80),
                                                               pConsecutivoRol int)
BEGIN

	UPDATE 	proyectoambienteweb.tusuario
    SET 	Identificacion = pIdentificacion,
			Nombre = pNombre,
            CorreoElectronico = pCorreo,
            ConsecutivoRol = CASE WHEN pConsecutivoRol != 0 THEN pConsecutivoRol ELSE ConsecutivoRol END
    WHERE	Consecutivo = pConsecutivo;

END ;;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `CambiarEstadoUsuario`(pConsecutivo bigint)
BEGIN

	/* Borrado físico
		DELETE FROM cursobd.tusuario
		WHERE	Consecutivo = pConsecutivo;
    */

	/*Borrado lógico*/
	UPDATE 	proyectoambienteweb.tusuario
    SET 	Activo = CASE WHEN Activo = 1 THEN 0 ELSE 1 END
    WHERE	Consecutivo = pConsecutivo;
    

END ;;


DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ConsultarRoles`()
BEGIN

	SELECT	Consecutivo, NombreRol
	FROM 	proyectoambienteweb.tRol;

END ;;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ConsultarUsuario`(pConsecutivo bigint)
BEGIN

	SELECT	U.Consecutivo,
			Identificacion,
			Nombre,
			CorreoElectronico,
			Activo,
			ConsecutivoRol,
            R.NombreRol
	FROM 	proyectoambienteweb.tusuario U
    INNER 	JOIN proyectoambienteweb.tRol R on U.ConsecutivoRol = R.Consecutivo
	WHERE 	U.Consecutivo = pConsecutivo;

END ;;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ConsultarUsuarios`(pConsecutivo bigint)
BEGIN

	SELECT	U.Consecutivo,
			Identificacion,
			Nombre,
			CorreoElectronico,
			Activo,
            CASE WHEN Activo = 1 THEN 'Activo' ELSE 'Inactivo' END 'DescripcionActivo',
			ConsecutivoRol,
            R.NombreRol
	FROM 	proyectoambienteweb.tusuario U
    INNER 	JOIN proyectoambienteweb.tRol R on U.ConsecutivoRol = R.Consecutivo
    WHERE 	U.Consecutivo != pConsecutivo;

END ;;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `IniciarSesion`(pCorreoElectronico varchar(80),
															pContrasena varchar(10))
BEGIN

	SELECT	U.Consecutivo,
			Identificacion,
			Nombre,
			CorreoElectronico,
			Activo,
			ConsecutivoRol,
            R.NombreRol
	FROM 	proyectoambienteweb.tusuario U
    INNER 	JOIN proyectoambienteweb.tRol R on U.ConsecutivoRol = R.Consecutivo
	WHERE 	CorreoElectronico = pCorreoElectronico
		AND Contrasena = pContrasena
        AND Activo = 1;

END ;;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `RecuperarAcceso`(pCorreoElectronico varchar(80))
BEGIN

	SELECT	Consecutivo,
			Identificacion,
			Nombre,
			CorreoElectronico,
			Activo,
			ConsecutivoRol
	FROM 	proyectoambienteweb.tusuario
	WHERE 	CorreoElectronico = pCorreoElectronico;

END ;;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `RegistrarUsuario`(pIdentificacion varchar(20),
															 pNombre varchar(255),
															 pCorreoElectronico varchar(80),
															 pContrasena varchar(10))
BEGIN

	INSERT INTO proyectoambienteweb.tusuario(Identificacion,Nombre,CorreoElectronico,Contrasena,Activo,ConsecutivoRol)
	VALUES	(pIdentificacion,pNombre,pCorreoElectronico,pContrasena,1,2);

END ;;



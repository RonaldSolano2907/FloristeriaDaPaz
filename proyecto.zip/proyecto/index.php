<?php
	header('location: View/home.php');
	?>
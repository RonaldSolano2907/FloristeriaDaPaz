<?php
    include_once 'layout.php';
?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Floristeria DaPaz</title>
    <meta name="author" content="Untree.co">
    <link rel="shortcut icon" type="image/jpg" href="images/Dapaz.jpg" />



    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="css/tiny-slider.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Start Header/Navigation -->
    <?php
            MostrarMenu();
        ?>

    <!-- End Header/Navigation -->

    <!-- Start Hero Section -->
    <div class="hero">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-5">
                    <div class="intro-excerpt">
                        <h1>Sobre nosotros</h1>
                        <p class="mb-3" style="font-size: 16px; color: #ffffff;">Somos una floristería con más de 5 años de experiencia 
                            especializados en trabajos con flores naturales. Nuestra historia comienza con una madre y sus hijas 
                            queriendo aportar en su comunidad donde vieron una oportunidad de negocio como lo es la venta de arreglos florales 
                            accesibles para todas las personas que desean dar un regalo a todas esas personas especiales. </p>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="hero-img-wrap">
                        <img src="images/Dapaz.jpg" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Hero Section -->
    <!-- Start Why Choose Us Section -->
    <div class="why-choose-section">
        <div class="container">
            <div class="row justify-content-between align-items-center">
                <div class="col-lg-6">
                    <h1 class="section-title">Nuestros servicios</h1>

                    <div class="row my-5">
                        <div class="mb-3">
                            <div class="feature">
                                <div class="icon">
                                    <img src="images/truck.svg" alt="Image" class="imf-fluid">
                                </div>
                                <h3 style="font-size: 18px;">Envio rapido</h3>
                                <p>Envios posibles el mismo dia de la compra.</p>
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="feature">
                                <div class="icon">
                                    <img src="images/bag.svg" alt="Image" class="imf-fluid">
                                </div>
                                <h3 style="font-size: 18px;">Facil de comprar</h3>
                                <p>Compra sencilla y amigable</p>
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="feature">
                                <div class="icon">
                                    <img src="images/support.svg" alt="Image" class="imf-fluid">
                                </div>
                                <h3 style="font-size: 18px;">Ayuda personalizada</h3>
                                <p>Te ayudamos a escoger ese regalo para cualquier ocasión</p>
                            </div>
                        </div>


                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="img-wrap">
                        <img src="images/rosas.jpg" alt="Image" class="img-fluid">
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Why Choose Us Section -->

    <!-- Start Footer Section -->
    <?php
            FinPagina();
        ?>
    <!-- End Footer Section -->



    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/tiny-slider.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>
<?php
    include_once 'layout.php';
?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Floristeria DaPaz</title>
    <meta name="author" content="Untree.co">
    <link rel="shortcut icon" type="image/jpg" href="images/Dapaz.jpg" />



    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="css/tiny-slider.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Start Header/Navigation -->
    <?php
            MostrarMenu();
        ?>

    <!-- End Header/Navigation -->

    <div class="container main-content">
        <div class="hero-section">
            <h1 class="main-title">Aqui se encontrara la información del carrito</h1>
        </div>

        <!-- Start Footer Section -->
        <?php
            FinPagina();
        ?>
        <!-- End Footer Section -->



        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/tiny-slider.js"></script>
        <script src="js/custom.js"></script>
</body>

</html>